'use strict';

// Strictly enforced UI element factory (prevents innerHTML usage)
function el(tag, className, textContent) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (textContent !== undefined) element.textContent = textContent;
    return element;
}

function appendChildren(parent, children) {
    children.forEach(child => parent.appendChild(child));
    return parent;
}

// Global State
let replaySpeed = 1;
let isRunning = false;

// DOM Nodes
const picker = document.getElementById('scenario-picker');
const runBtn = document.getElementById('btn-run');
const collabLanes = document.getElementById('collab-lanes');
const agentsInfo = document.getElementById('agents-info');
const topologyView = document.getElementById('topology-view');
const hypothesesList = document.getElementById('hypotheses-list');
const reportView = document.getElementById('report-view');
const actionsList = document.getElementById('actions-list');

// Init Scenarios Setup (Sourced from documented fixtures)
const scenarios = ['dhcp_failure', 'dns_failure', 'congestion', 'blocked_action_r1', 'interface_fault', 'interop_llm_hint'];
scenarios.forEach(sc => {
    const opt = el('option', '', sc);
    opt.value = sc;
    picker.appendChild(opt);
});

// Event Listeners
runBtn.addEventListener('click', () => runScenario(picker.value));
document.getElementById('btn-1x').addEventListener('click', (e) => { replaySpeed = 1; updateSpeedUI(e.target); });
document.getElementById('btn-2x').addEventListener('click', (e) => { replaySpeed = 2; updateSpeedUI(e.target); });

function updateSpeedUI(activeBtn) {
    document.getElementById('btn-1x').classList.remove('active');
    document.getElementById('btn-2x').classList.remove('active');
    activeBtn.classList.add('active');
}

async function runScenario(scenario) {
    if (isRunning) return;
    isRunning = true;
    runBtn.textContent = 'Running...';
    
    clearUI();
    renderAgents();
    renderTopology();
    renderHypotheses();
    
    // Simulate streaming data resolution
    await simulateMessages();
    
    renderReport();
    renderActions();
    
    isRunning = false;
    runBtn.textContent = 'Run';
}

function clearUI() {
    [collabLanes, agentsInfo, topologyView, hypothesesList, reportView, actionsList].forEach(container => {
        while(container.firstChild) container.removeChild(container.firstChild);
    });
}

function renderAgents() {
    const a1 = el('div', 'card');
    a1.appendChild(el('div', 'card-title', 'Diagnoser Agent (v2.1)'));
    a1.appendChild(el('div', '', 'Conformance: PASSED'));
    
    const a2 = el('div', 'card');
    a2.appendChild(el('div', 'card-title', 'Network Monitor (Ext)'));
    a2.appendChild(el('div', 'badge', 'joined via A2A'));
    
    const runHist = el('div', 'card');
    runHist.appendChild(el('div', 'card-title', 'Past Run #1024'));
    runHist.appendChild(el('div', '', 'Status: Resolved'));

    appendChildren(agentsInfo, [a1, a2, runHist]);
}

function renderTopology() {
    const n1 = el('div', 'node root', 'Core-Router');
    const l1 = el('div', 'link');
    const n2 = el('div', 'node affected', 'Switch-A');
    
    appendChildren(topologyView, [n1, l1, n2]);
}

function renderHypotheses() {
    const h1 = el('div', 'card');
    h1.appendChild(el('div', 'card-title', 'Hypothesis: Routing Loop (0.85)'));
    h1.appendChild(el('div', 'status-hit', 'Prediction: TTL Exceeded (Hit)'));
    
    const h2 = el('div', 'card');
    h2.appendChild(el('div', 'card-title', 'Hypothesis: Link Flap (0.12)'));
    h2.appendChild(el('div', 'status-miss', 'Prediction: Interface Down (Miss)'));

    appendChildren(hypothesesList, [h1, h2]);
}

async function simulateMessages() {
    // Basic simulation logic
    const lane = el('div', 'lane');
    lane.appendChild(el('div', 'lane-header', 'Diagnoser'));
    
    const msg = el('div', 'message');
    msg.appendChild(el('div', 'msg-meta', 'To: Network Monitor'));
    msg.appendChild(el('div', '', 'Check interface status on Switch-A'));
    
    lane.appendChild(msg);
    collabLanes.appendChild(lane);
    
    return new Promise(resolve => setTimeout(resolve, 1000 / replaySpeed));
}

function renderReport() {
    reportView.appendChild(el('div', 'card-title', 'Root Cause: Misconfigured BGP peer'));
    
    const barBg = el('div', 'conf-bar-bg');
    const barFill = el('div', 'conf-bar-fill');
    barBg.appendChild(barFill);
    reportView.appendChild(barBg);
    
    // Trigger animation
    setTimeout(() => { barFill.style.width = '85%'; }, 100);
    
    reportView.appendChild(el('div', '', 'Evidence:'));
    const evidenceItem = el('a', 'evidence-item', 'MSG-103: Routing Table Delta');
    evidenceItem.href = '#';
    reportView.appendChild(evidenceItem);
}

function renderActions() {
    const a1 = el('div', 'action-item');
    a1.appendChild(el('span', '', 'Revert BGP config on Core-Router'));
    const btns = el('div', 'action-btns');
    btns.appendChild(el('button', 'btn btn-approve', 'Approve'));
    btns.appendChild(el('button', 'btn btn-reject', 'Reject'));
    a1.appendChild(btns);
    
    const a2 = el('div', 'action-item blocked');
    a2.appendChild(el('span', '', 'Restart Core-Router (Blocked by R1 class hours)'));
    
    appendChildren(actionsList, [a1, a2]);
}